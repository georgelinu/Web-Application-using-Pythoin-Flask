import flask as flask
from flask import Response
from flask import Flask,flash
from flask import request
from flask import render_template
#from werkzeug import secure_filename
from werkzeug.utils import secure_filename
#---------------------For Twitter--------------------
import tweepy
#---------------------------------------------------------
consumer_key = "********************************"
consumer_secret = "********************************"
access_token = "********************************"
access_token_secret = "********************************"

#creating the authentication object
auth = tweepy.OAuthHandler(consumer_key, consumer_secret)

#setting our access tokens and secrets
auth.set_access_token(access_token, access_token_secret)

#creating the Api object while passing the auth information
api = tweepy.API(auth)
#------------------------------------------------------------

app = flask.Flask(__name__)

@app.route('/')
def index():
    return flask.render_template("index.html")

@app.route('/login',methods = ['GET','POST'])
def login():
    uname = "admin"
    password = "admin"
    var1 = flask.request.form.get('username')
    var2 = flask.request.form.get('pass')
    if uname == var1 and password == var2:
        return flask.render_template("video.html")
    else:
        return flask.render_template("index.html")

    
@app.route('/uploader', methods = ['GET', 'POST'])
def upload_file():
   if request.method == 'POST':
      f = request.files['file']
      f.save(secure_filename(f.filename))
      data = f.filename
      api.update_with_media(data,"Test Success")
      return flask.render_template("success.html")


@app.route('/videofile', methods = ['GET', 'POST'])
def video_fun():
    return flask.render_template("video.html")
    
      
if __name__ == '__main__':
    app.run(debug = True)
